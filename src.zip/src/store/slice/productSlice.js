import { createSlice } from '@reduxjs/toolkit';

const initialState = {
    selectedProduct: null,
    qrCode: ''
};

const productSlice = createSlice({
    name: 'product',
    initialState,
    reducers: {
        setSelectedProduct(state, action) {
            state.selectedProduct = action.payload;
        },
        addSerial(state, action) {
            state.qrCode += `${action.payload}|`;
        }
    }
});

export const { setSelectedProduct, addSerial } = productSlice.actions;
export const selectSelectedProduct = (state) => state.product.selectedProduct;
export const selectQrCode = (state) => state.product.qrCode;

export default productSlice.reducer;
