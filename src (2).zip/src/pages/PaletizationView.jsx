import icons from "../assets/icons/icons";
import React, { useEffect, useState, useRef } from "react";
import ReactToPrint from "react-to-print";
import { makeStyles } from "@material-ui/core/styles";
import Button from "@material-ui/core/Button";
import InputLabel from "@material-ui/core/InputLabel";
import Input from "@material-ui/core/Input";
import MenuItem from "@material-ui/core/MenuItem";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import BrowserPrintComponent from "../printerComponent";
import {
  setSelectedProduct,
  selectSelectedProduct,
  addSerial,
} from "../store/slice/productSlice";
import {
  Add,
  Barcode,
  Box,
  Box1,
  BoxAdd,
  Category,
  Cd,
  FormatSquare,
  Grid8,
  Hashtag,
  HashtagSquare,
  Health,
  Quant,
  Notepad2,
  Scan,
  Edit,
  Lock,
  Archive,
  ArchiveBox,
  Menu,
  HambergerMenu,
} from "iconsax-react";

import Stepper from "@keyvaluesystems/react-vertical-stepper";

import GraphicHistory from "../partials/paletization/GraphicHistory";

import useScanDetection from "use-scan-detection";

import { useSelector, useDispatch } from "react-redux";

import ModalBlank from "../components/ModalBlank";

import {
  selectOrderSelected,
  metadataOrderSelected,
  getProductDetail,
} from "../store/slice/orderSelectedSlice";

import {
  addEventToPaletizationLog,
  selectPaletizationLog,
  addEventToFanLog,
  setFanLog,
} from "../store/slice/eventsLogSlice";
import {
  getTestResults,
  selectTestResults,
  selectGlobalStatus,
  setGlobalStatus,
  setTestResults,
} from "../store/slice/testResultSlice";
import {
  getLastPallet,
  createPallet,
  selectPallet,
  selectComponents,
  mountComponent,
  processInSAP,
  addSerialToBoxInSAP,
  getPalletSetupFromSAP, 
  getCompressor,
  setComponentsJoined,
  setComponents,
  selectLoadingProcessInSap,
  selectPalletNotified,
} from "../store/slice/palletsSlice";
import LabelPrinting from "../partials/genealogy/LabelPrinting";
import ComponentsTable from "../partials/paletization/ComponentsTable";
import greenLight from "../assets/images/green.png";
import redLight from "../assets/images/red.png";

import {
  notifyPalletScanned,
  notifyProductScanned,
} from "../partials/paletization/Toasts";
import GridView from "../components/GridView";
import GridViewPallet from "../components/GridViewPallet";
const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    flexWrap: "wrap",
    "& button": {
      flexBasis: "20%",
      margin: "2%",
    },
  },
  container: {
    display: "flex",
    flexWrap: "wrap",
  },
  formControl: {
    marginTop: "5%",
    marginBottom: "7%",
    minWidth: 120,
  },
}));
function PaletizationView() {
  const dispatch = useDispatch();
  const [activeTab, setActiveTab] = useState(0);
  const handleTabClick = (index) => {
    setActiveTab(index);
  };

  const tabs = ["Caja", "Pallet"];

  const [dangerDiffValues, setDangerDiffValues] = useState(false);
  const [confirmEditDiffValues, setConfirmEditDiffValues] = useState(false);
  const [dangerEditQtyPalletModalOpen, setDangerEditQtyPalletModalOpen] =
    useState(false);
  const [confirmEditQtyPallet, setConfirmEditQtyPallet] = useState(false);
  const [value, setValue] = useState("1452");
  const [editable, setEditable] = useState(false); // Cambié el estado inicial a 'false'
  const inputRef = useRef(null);

  const classes = useStyles();
  const [open, setOpen] = React.useState(false);
  const [deviceList, setDevices] = React.useState([]);
  const [printer, setPrinter] = React.useState(null);
  const [zebraPrinter, setZebraPrinter] = React.useState(null);
  const [data, setData] = useState([]);
  const [counterProduct, setCounterProduct] = React.useState(0);
  const [counterBox, setCounterBox] = React.useState(0);
  /* const [selectedProduct, setSelectedProduct] = useState(null); */

  const selectedProduct = useSelector(selectSelectedProduct);

  console.log("selectedProductView", selectedProduct);

  const handleAddSerial = (serial) => {
    dispatch(addSerial(serial));
  };

  const updateSelectedProduct = (product) => {
    dispatch(setSelectedProduct(product));
  };

  const handleChange = (event) => {
    setValue(event.target.value);
  };

  const toggleEditable = (e) => {
    e.stopPropagation();
    setDangerEditQtyPalletModalOpen(true);
  };

  useEffect(() => {
    if (confirmEditQtyPallet) {
      setEditable(!editable); // Invierte el estado de editable
      if (!editable) {
        inputRef.current.focus(); // Pone en foco el input cuando se activa la edición
      }
      setConfirmEditQtyPallet(false); //
    } else {
      console.log("No confirmó edición");
    }
  }, [confirmEditQtyPallet]);


 //const openProductList = useSelector(selectProductList);
 


  useEffect(() => {
    setData([
      {
        product: {
          mandt: "300",
          matnr: "000000000519700002",
          numin: "G",
          modelo: "EFM25DDUF04502A-P1",
          voltage: "100-240V 1~50-60HZ",
          potencia: "25W",
          corrente: "0.39-0.69A",
          iprating: "IP67",
          speed_conf: "CCWSE/CCWSE",
          speed_rot: "800/2200 RPM",
          storage_temp: " -40Â°C TO +80Â°C",
          pallect_data: "51970002F00P",
        },
        pallet: {
          mandt: "300",
          matnr: "000000000519700002",
          box_x_line: 4,
          num_lines: 8,
        },
        box: {
          mandt: "300",
          matnr: "000000000519700002",
          capacity: 24,
          length: 6,
          width: 4,
        },
        accessories: [
        {
          sku: "13053063",
          description: "Flanged Nut",
          quantity: "4"
        },
        {
          sku: "13053064",
          description: "Rear Fixation Screw",
          quantity: "1"
        }
        ]
      },
      {
        product: {
          mandt: "300",
          matnr: "000000000519700003",
          numin: "G",
          modelo: "EFM15SDUC06002A-P1",
          voltage: "100-240V 1~50-60HZ",
          potencia: "15W",
          corrente: "0.24-0.40A",
          iprating: "IP67",
          speed_conf: "CCWSE",
          speed_rot: "1550 RPM",
          storage_temp: " -40Â°C TO +80Â°C",
          pallect_data: "519700003F00P",
        },
        pallet: {
          mandt: "300",
          matnr: "000000000519700003",
          box_x_line: 4,
          num_lines: 8,
        },
        box: {
          mandt: "300",
          matnr: "000000000519700003",
          capacity: 24,
          length: 6,
          width: 4,
        },
      },
      {
        product: {
          mandt: "300",
          matnr: "000000000519700004",
          numin: "G",
          modelo: "EFM15DDUF04502A-P1",
          voltage: "100-240V 1~50-60HZ",
          potencia: "15W",
          corrente: "0.24-0.40A",
          iprating: "IP67",
          speed_conf: "CCWSE/CCWSE",
          speed_rot: "800/1550 RPM",
          storage_temp: " -40Â°C TO +80Â°C",
          pallect_data: "519700004B00P",
        },
        pallet: {
          mandt: "300",
          matnr: "000000000519700004",
          box_x_line: 4,
          num_lines: 8,
        },
        box: {
          mandt: "300",
          matnr: "000000000519700004",
          capacity: 24,
          length: 6,
          width: 4,
        },
      },
      {
        product: {
          mandt: "300",
          matnr: "000000000519700005",
          numin: "G",
          modelo: "EFM15SDUF02501A-P1",
          voltage: "100-240V 1~50-60HZ",
          potencia: "15W",
          corrente: "0.24-0.40A",
          iprating: "IP67",
          speed_conf: "CCWSE",
          speed_rot: "1550 RPM",
          storage_temp: " -40Â°C TO +80Â°C",
          pallect_data: "519700005R00P",
        },
        pallet: {
          mandt: "300",
          matnr: "000000000519700005",
          box_x_line: 4,
          num_lines: 8,
        },
        box: {
          mandt: "300",
          matnr: "000000000519700005",
          capacity: 24,
          length: 6,
          width: 4,
        },
      },
      {
        product: {
          mandt: "300",
          matnr: "000000000519700006",
          numin: "G",
          modelo: "EFM25SDUL04501A-S1",
          voltage: "100-240V 1~50-60HZ",
          potencia: "25W",
          corrente: "0.39-0.69A",
          iprating: "IP67",
          speed_conf: "CCWSE",
          speed_rot: "1550 RPM",
          storage_temp: " -40Â°C TO +80Â°C",
          pallect_data: "519700006A00P",
        },
        pallet: {
          mandt: "300",
          matnr: "000000000519700006",
          box_x_line: 4,
          num_lines: 8,
        },
        box: {
          mandt: "300",
          matnr: "000000000519700006",
          capacity: 24,
          length: 6,
          width: 4,
        },
      },
      {
        product: {
          mandt: "300",
          matnr: "000000000519700007",
          numin: "G",
          modelo: "EFM25FDUL04503A-S1",
          voltage: "100-240V 1~50-60HZ",
          potencia: "25W",
          corrente: "0.39-0.69A",
          iprating: "IP67",
          speed_conf: "CWOSE/CCWOSE/CWOSE/CCWOSE",
          speed_rot: "1550/1550/1650/1650 RPM",
          storage_temp: " -40Â°C TO +80Â°C",
          pallect_data: "519700007A00P",
        },
        pallet: {
          mandt: "300",
          matnr: "000000000519700007",
          box_x_line: 4,
          num_lines: 8,
        },
        box: {
          mandt: "300",
          matnr: "000000000519700007",
          capacity: 24,
          length: 6,
          width: 4,
        },
      },
      {
        product: {
          mandt: "300",
          matnr: "000000000519700008",
          numin: "G",
          modelo: "EFM25SDUL04502A-S1",
          voltage: "100-240V 1~50-60HZ",
          potencia: "25W",
          corrente: "0.39-0.69A",
          iprating: "IP67",
          speed_conf: "CWSE",
          speed_rot: "1550 RPM",
          storage_temp: " -40Â°C TO +80Â°C",
          pallect_data: "519700008A00P",
        },
        pallet: {
          mandt: "300",
          matnr: "000000000519700008",
          box_x_line: 4,
          num_lines: 8,
        },
        box: {
          mandt: "300",
          matnr: "000000000519700008",
          capacity: 24,
          length: 6,
          width: 4,
        },
      },
      {
        product: {
          mandt: "300",
          matnr: "000000000519700009",
          numin: "G",
          modelo: "EFM25DDUX06003A-P1",
          voltage: "100-240V 1~50-60HZ",
          potencia: "25W",
          corrente: "0.39-0.69A",
          iprating: "IP67",
          speed_conf: "CCWSE/CWSE",
          speed_rot: "1550/1550 RPM",
          storage_temp: " -40Â°C TO +80Â°C",
          pallect_data: "519700009F00P",
        },
        pallet: {
          mandt: "300",
          matnr: "000000000519700009",
          box_x_line: 4,
          num_lines: 8,
        },
        box: {
          mandt: "300",
          matnr: "000000000519700009",
          capacity: 24,
          length: 6,
          width: 4,
        },
      },
      {
        product: {
          mandt: "300",
          matnr: "000000000519700010",
          numin: "G",
          modelo: "EFM25DDUX06003A-P1",
          voltage: "100-240V 1~50-60HZ",
          potencia: "25W",
          corrente: "0.39-0.69A",
          iprating: "IP67",
          speed_conf: "CCWSE/CWSE",
          speed_rot: "1800/1800 RPM",
          storage_temp: " -40Â°C TO +80Â°C",
          pallect_data: "519700010F00P",
        },
        pallet: {
          mandt: "300",
          matnr: "000000000519700010",
          box_x_line: 4,
          num_lines: 8,
        },
        box: {
          mandt: "300",
          matnr: "000000000519700010",
          capacity: 24,
          length: 6,
          width: 4,
        },
      },
      {
        product: {
          mandt: "300",
          matnr: "000000000519700011",
          numin: "G",
          modelo: "EFM25FDUF04504A-P1",
          voltage: "100-240V 1~50-60HZ",
          potencia: "25W",
          corrente: "0.39-0.69A",
          iprating: "IP67",
          speed_conf: "CCWSE/CCWSE/CCWSE/CCWSE",
          speed_rot: "1550/800/1300/2200 RPM",
          storage_temp: " -40Â°C TO +80Â°C",
          pallect_data: "519700011B00P",
        },
        pallet: {
          mandt: "300",
          matnr: "000000000519700011",
          box_x_line: 4,
          num_lines: 8,
        },
        box: {
          mandt: "300",
          matnr: "000000000519700011",
          capacity: 24,
          length: 6,
          width: 4,
        },
      },
      {
        product: {
          mandt: "300",
          matnr: "000000000519700012",
          numin: "G",
          modelo: "EFM15SDUF04503A-P1",
          voltage: "100-240V 1~50-60HZ",
          potencia: "15W",
          corrente: "0.24-0.40A",
          iprating: "IP67",
          speed_conf: "CCWSE",
          speed_rot: "1300 RPM",
          storage_temp: " -40Â°C TO +80Â°C",
          pallect_data: "519700012B00P",
        },
        pallet: {
          mandt: "300",
          matnr: "000000000519700012",
          box_x_line: 4,
          num_lines: 8,
        },
        box: {
          mandt: "300",
          matnr: "000000000519700012",
          capacity: 24,
          length: 6,
          width: 4,
        },
      },
      {
        product: {
          mandt: "300",
          matnr: "000000000519700013",
          numin: "G",
          modelo: "EFM25SDUF04503A-P1",
          voltage: "100-240V 1~50-60HZ",
          potencia: "25W",
          corrente: "0.39-0.69A",
          iprating: "IP67",
          speed_conf: "CCWSE",
          speed_rot: "1300 RPM",
          storage_temp: " -40Â°C TO +80Â°C",
          pallect_data: "519700013B00P",
        },
        pallet: {
          mandt: "300",
          matnr: "000000000519700013",
          box_x_line: 4,
          num_lines: 8,
        },
        box: {
          mandt: "300",
          matnr: "000000000519700013",
          capacity: 24,
          length: 6,
          width: 4,
        },
      },
      {
        product: {
          mandt: "300",
          matnr: "000000000519700014",
          numin: "G",
          modelo: "EFM25SDUF04501A-P1",
          voltage: "100-240V 1~50-60HZ",
          potencia: "25W",
          corrente: "0.39-0.69A",
          iprating: "IP67",
          speed_conf: "CCWSE",
          speed_rot: "1550 RPM",
          storage_temp: " -40Â°C TO +80Â°C",
          pallect_data: "519700014B00P",
        },
        pallet: {
          mandt: "300",
          matnr: "000000000519700014",
          box_x_line: 4,
          num_lines: 8,
        },
        box: {
          mandt: "300",
          matnr: "000000000519700014",
          capacity: 24,
          length: 6,
          width: 4,
        },
      },
      {
        product: {
          mandt: "300",
          matnr: "000000000519700015",
          numin: "G",
          modelo: "EFM15SDUF04504A-P1",
          voltage: "100-240V 1~50-60HZ",
          potencia: "15W",
          corrente: "0.24-0.40A",
          iprating: "IP67",
          speed_conf: "CCWSE",
          speed_rot: "1550 RPM",
          storage_temp: " -40Â°C TO +80Â°C",
          pallect_data: "519700015B00P",
        },
        pallet: {
          mandt: "300",
          matnr: "000000000519700015",
          box_x_line: 4,
          num_lines: 8,
        },
        box: {
          mandt: "300",
          matnr: "000000000519700015",
          capacity: 24,
          length: 6,
          width: 4,
        },
      },
    ]);
  }, []);

  /* useEffect(() => {
    let serialNumber1 = "000000000519700002";
    if (serialNumber1 && data.length > 0) {
      const foundProduct = data.find(
        (item) => item.product.matnr === serialNumber1
      );
      if (foundProduct) {
        setSelectedProduct(foundProduct);
      } else {
        setSelectedProduct(null);
      }
    }
  }, [data]); */

 
    

  useEffect(() => {
    //fetchPalletData();
    dispatch(getPalletSetupFromSAP(serialNumber, palletNumber, orderSelected.aufnr, orderSelected.matnr));

    let serialNumber1 = "000000000519700002";
    if (serialNumber1 && data.length > 0) {
      const foundProduct = data.find(
        (item) => item.product.matnr === serialNumber1
      );
      if (foundProduct) {
        dispatch(setSelectedProduct(foundProduct));
      } else {
        dispatch(setSelectedProduct(null));
      }
    }
  }, [data, dispatch]);

  let totalProducts = 0;
  let totalBoxes = 0;

  if (
    data &&
    data[0]?.pallet?.box_x_line &&
    data[0]?.pallet?.num_lines &&
    data[0]?.box?.capacity
  ) {
    totalProducts =
      (data[0]?.pallet?.box_x_line ?? 0) *
      (data[0]?.pallet?.num_lines ?? 0) *
      (data[0]?.box?.capacity ?? 0);

    totalBoxes = data[0]?.box?.capacity ?? 0; // Acceso seguro a capacity de box
  } else {
    console.error("El objeto data o alguna propiedad necesaria es undefined");
  }

  const handleKeyPress = (event) => {
    if (event.key === "Enter") {
      setEditable(false); // Bloquea el input si se presiona la tecla Enter
    }
  };

  const handleSave = () => {
    setEditable(false); // Bloquea el input cuando se guarda
  };

  const [totalMontadosValue, setTotalMontadosValue] = useState("");
  const [totalMontadosEditable, setTotalMontadosEditable] = useState(false); // Cambié el estado inicial a 'false'
  const totalMontadosRef = useRef(null);

  const handleChangeMontados = (event) => {
    setTotalMontadosValue(event.target.value);
  };

  const toggleEditableMontados = () => {
    setTotalMontadosEditable(!totalMontadosEditable); // Invierte el estado de editable
    if (!totalMontadosEditable) {
      totalMontadosRef.current.focus(); // Pone en foco el input cuando se activa la edición
    }
  };

  const handleKeyPressMontados = (event) => {
    if (event.key === "Enter") {
      if (value != totalMontadosValue) {
        setDangerDiffValues(true);
      }
      setTotalMontadosEditable(false); // Bloquea el input si se presiona la tecla Enter
    }
  };

  const handleSaveMontados = () => {
    if (value != totalMontadosValue) {
      setDangerDiffValues(true);
    }
    setTotalMontadosEditable(false); // Bloquea el input si se presiona la tecla Enter
  };

  const testResultsList = useSelector(selectTestResults);
  const globalStatus = useSelector(selectGlobalStatus);
  const orderSelected = useSelector(selectOrderSelected);
  const metadata = useSelector(metadataOrderSelected);
  const paletizationLog = useSelector(selectPaletizationLog);
  const palletNotified = useSelector(selectPalletNotified);

  const [infoModalOpen, setInfoModalOpen] = useState(false);

  const [barcodePallet, setBarcodePallet] = useState("Nuevo pallet");
  const [idAuto, setIdAuto] = useState(1);
  const [barcodeProduct, setBarcodeProduct] = useState("Escanea producto");

  const [treeData, setTreeData] = useState([]);

  /* const dispatch = useDispatch(); */

  const labelRef = useRef();

  const [selectedItems, setSelectedItems] = useState([]);

  const palletSelected = useSelector(selectPallet);

  const componentsList = useSelector(selectComponents);

  const isLoading = useSelector(selectLoadingProcessInSap);

  const handleSelectedItems = (selectedItems) => {
    setSelectedItems([...selectedItems]);
  };

  const fetchSerialData = async (code) => {
    console.log("Estoy aca");
    try {
      const url = `http://localhost:5005/get_tester_result?serial=${code}`;
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      if (!response.ok) {
        throw new Error("No se pudo obtener la respuesta del servidor.");
      }
      const responseData = await response.json();
      console.log("Respuesta del servidor:", responseData);
      return responseData;
    } catch (error) {
      console.error(error);
    }
  };

  const [serialNumber, setSerialNumber] = useState("");
  const [palletNumber, setPalletNumber] = useState("");
  const [trafficLightState, setTrafficLightState] = useState("");

  useScanDetection({
    onComplete: async (code) => {
      console.log(code);

      let formattedCode = code.replace(/Shift/g, "").toUpperCase();
     
      if (formattedCode == "24VMTN" || 
          formattedCode == "AAAAAA") {
        formattedCode = "824VMTN";
      }
      //alert(formattedCode);
      if (formattedCode.startsWith("753153642022") || 
          formattedCode.startsWith("53153642022") ||
          formattedCode.startsWith("753153642022")) {
        formattedCode = "519700002TESTINGQ";
         //alert(formattedCode);
      }
      console.log("Mostrando Order Slected Matnr");
      console.log(orderSelected.matnr);
      console.log("Finalizando Order Slected Matnr");
      //alert("Order Selected", orderSelected.matnr);

      if (formattedCode.startsWith(orderSelected.matnr)) {
        setSerialNumber(formattedCode);
        dispatch(addSerial(formattedCode));
        notifyProductScanned(formattedCode);

        const codeScannedEvent = {
          text: "Fan escaneado: " + formattedCode,
          timestamp: new Date().toISOString(),
        };

        dispatch(addEventToFanLog(codeScannedEvent));

        const createFanEvent = {
          text: "Consultando registro de Fan: " + formattedCode,
          timestamp: new Date().toISOString(),
        };

        dispatch(addEventToPaletizationLog(createFanEvent));

        addElement();
        let responseDatabase = await fetchSerialData(formattedCode);
        console.log('response Database antes try',responseDatabase)
      
        //setTrafficLightState(1);
        let variableFancode = responseDatabase[0].FanCode;
        console.log("Fancode=",responseDatabase[0].FanCode );
        console.log("Result=", responseDatabase[0].Result);
        setTrafficLightState(responseDatabase[0].Result);
       
        return;
      }

      if (/^[A-Z0-9]{7}$/.test(formattedCode)) {
        setPalletNumber(formattedCode);
        console.log("pallet",formattedCode)

        const codeScannedEvent = {
          text: "Pallet escaneado: " + formattedCode,
          timestamp: new Date().toISOString(),
        };
        setBarcodePallet(formattedCode);
        dispatch(addEventToPaletizationLog(codeScannedEvent));
        dispatch(createPallet(formattedCode));

        const createPalletEvent = {
          text: "Consultando registro de Pallet: " + formattedCode,
          timestamp: new Date().toISOString(),
        };
        notifyPalletScanned(formattedCode);
        dispatch(addEventToPaletizationLog(createPalletEvent));

        return;
      }else{
       // if (formattedCode) {
        //alert(formattedCode);
        alert(`El producto escaneado no pertenece a esta línea de producción`);
       // }
      }
    },
  });

  const [currentStepIndex, setCurrentStepIndex] = useState(0);

  var stepsArray = [
    {
      label: "Prueba eléctrica",
      description: "Aprobada, sin errores, finalizada hace 14 minutos.",
      status: "visited",
    },
    {
      label: "Prueba de vacío",
      description: "En proceso, iniciada el 9/05/2023 a las 12:30 PM.",
      status: "unvisited",
    },
  ];

  function formatTimestampToDDMMYYYYHHMMSS(timestamp) {
    const date = new Date(timestamp);

    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const year = date.getFullYear();

    const hours = String(date.getHours()).padStart(2, "0");
    const minutes = String(date.getMinutes()).padStart(2, "0");
    const seconds = String(date.getSeconds()).padStart(2, "0");

    return `${day}/${month}/${year} ${hours}:${minutes}:${seconds}`;
  }

  const stylesOverride = {
    LabelTitle: (step, stepIndex) => ({ marginLeft: "8px", fontSize: 15 }),
    ActiveLabelTitle: (step, stepIndex) => ({
      marginLeft: "0px",
      fontSize: 15,
    }),
    LabelDescription: (step, stepIndex) => ({
      marginLeft: "8px",
      fontSize: 13,
    }),
    ActiveLabelDescription: (step, stepIndex) => ({
      marginLeft: "0px",
      fontSize: 13,
    }),
    LineSeparator: (step, stepIndex) => ({ borderRight: "2px solid #dfdff2" }),
    InactiveLineSeparator: (step, stepIndex) => ({
      borderRight: "2px solid #dfdff2",
    }),
    Bubble: (step, stepIndex) => (
      console.log(stepIndex === currentStepIndex),
      console.log(step.status),
      {
        width: "40px",
        height: "40px",
        backgroundColor: step.status === "skipped" ? "red" : "#15B053",
        color: "#fff",
      }
    ),
    ActiveBubble: (step, stepIndex) => ({
      width: "40px",
      height: "40px",
      backgroundColor: step.status === "skipped" ? "red" : "#15B053",
      color: "#fff",
      background: "#15B053",
      border:
        step.status === "skipped" ? "7px solid #ee9090" : "7px solid #A1DFBA",
    }),
    InActiveBubble: (step, stepIndex) => ({
      width: "40px",
      height: "40px",
      backgroundColor: "#F0F1F3",
      color: "#000000",
    }),
  };

  function handleClickNewPallet() {
    getLastPallet()
      .then((result) => {
        const { nuevoIdentificador, id } = result;
        // Hacer algo con el nuevo identificador recibido
        console.log("El nuevo identificador es:", nuevoIdentificador);
        setBarcodePallet(nuevoIdentificador);

        setIdAuto(id);
      })
      .catch((error) => {
        // Manejar cualquier error que pueda ocurrir
        console.error("Hubo un error:", error);
      });
  }

  function handleNew() {
    console.log("Handle new step");
    setBarcodePallet("Nuevo pallet");
    setBarcodeProduct("Escanea producto");
    setValue("1452");
    setTotalMontadosValue("");
    dispatch(setGlobalStatus(""));
    dispatch(setTestResults([]));
    dispatch(setComponentsJoined(false));
    dispatch(setComponents([]));
  }

  function handleNewBox() {
    console.log("Abriendo caja");
  }

  function handleCloseBox() {
    console.log("Cerrando caja");

    if (elements.length !== 24) {
      const confirmClose = confirm(
        "El número total de elementos no es 24. ¿Desea confirmar el cierre de la caja de todos modos?"
      );

      if (!confirmClose) {
        return;
      }
    }

    dispatch(addEventToPaletizationLog("Agrega en la consola"));

    alert("Se agregará la caja en el pallet.");

    if (pallet.length < 4 * 6) {
      const nextIndex = pallet.length;
      const row = 7 - Math.floor(nextIndex / 4);
      const col = nextIndex % 4;

      setPallet([...pallet, { row, col }]);
      setElements([]);
      incrementBoxCounter();
    }
  }

  function handleClosePallet() {
    console.log("Cerrando pallet");
    handleNotify();
  }

  function handleNotify() {
    //var palletNumber = "824VM30";
    const codeScannedEvent = {
      text: "Creando pallet: " + palletNumber,
      timestamp: new Date().toISOString(),
    };
    dispatch(addEventToPaletizationLog(codeScannedEvent));
    dispatch(
      createPallet(
        "MX2FA120",
        orderSelected.aufnr,
        orderSelected.matnr,
        palletNumber,
        "768",
        idAuto
      )
    );

    //alert("Despues de Creando pallet y antes de processInSAP");

    setTimeout(() => {
      dispatch(processInSAP(orderSelected, palletNumber, totalMontadosValue));
    }, 400);
  }

  function buildTreeData(obj) {
    if (typeof obj === "undefined" || Object.keys(obj).length === 0) {
      console.log("Boom undefined");
      return [];
    } else {
      const treeData = [];
      const mainMatnr = obj.matnr.slice(-9); // Obtener los últimos 9 caracteres de matnr

      const parentNode = {
        id: 1,
        label: mainMatnr,
        children: [],
      };

      const childNode = {
        id: 2,
        label: obj.components[0]?.matnr ?? "",
      };

      parentNode.children.push(childNode);
      treeData.push(parentNode);

      return treeData;
    }
  }

  const [expandedNodes, setExpandedNodes] = useState([]);

  const toggleNode = (nodeId) => {
    if (expandedNodes.includes(nodeId)) {
      setExpandedNodes(expandedNodes.filter((id) => id !== nodeId));
    } else {
      setExpandedNodes([...expandedNodes, nodeId]);
    }
  };

  const renderNode = (node) => {
    const isNodeExpanded = expandedNodes.includes(node.id);
    const hasChildNodes = node.children && node.children.length > 0;

    return (
      <div key={node.id} className="tree-node">
        <div
          className={`tree-node__label ${
            hasChildNodes ? "tree-node__label--clickable" : ""
          }`}
          onClick={() => hasChildNodes && toggleNode(node.id)}
        >
          {hasChildNodes && (
            <span
              className={`tree-node__icon ${
                isNodeExpanded
                  ? "tree-node__icon--expanded"
                  : "tree-node__icon--collapsed"
              }`}
            ></span>
          )}
          {node.label}
        </div>
        {isNodeExpanded && hasChildNodes && (
          <div className="tree-node__children">
            {node.children.map((childNode) => renderNode(childNode))}
          </div>
        )}
      </div>
    );
  };

  const [elements, setElements] = useState([]);
  const [pallet, setPallet] = useState([]);

 const addElement = () => {
    console.log("AddElemnt")
    const nextIndex = elements.length;
    const row = Math.floor(nextIndex / 6); // Assuming columns is 6
    const col = nextIndex % 6;

    if (row < 4) {
      // Assuming rows is 4
      setElements([...elements, { row, col }]);
    }

    if (nextIndex === 24) {
      dispatch(addEventToPaletizationLog("Agrega en la consola"));

      //alert(
      //  "Se ha alcanzado el límite de 24 productos. Se agregará una caja en el pallet."
      //);

      addElementToPallet();
    } else {
      incrementProductCounter();
    }
    //alert("Antes de enviar serial a box, el matnr=", orderSelected.matnr);
    dispatch(addSerialToBoxInSAP(serialNumber, palletNumber, orderSelected.aufnr, orderSelected.matnr));

  };

  const removeElement = () => {
    setElements(elements.slice(0, -1));
    decrementProductCounter();
  };

  /* const addElementToPallet = () => {
    if (elements.length >= 4 * 6 && pallet.length < 4 * 6) {
      const nextIndex = pallet.length;
      const row = 7 - Math.floor(nextIndex / 4);
      const col = nextIndex % 4;

      setPallet([...pallet, { row, col }]);

      setElements([]);
      incrementBoxCounter();
    }
  }; */

  const addElementToPallet = () => {
    if (elements.length >= 4 * 6 && pallet.length < 4 * 6) {
      const nextIndex = pallet.length;
      const row = 7 - Math.floor(nextIndex / 4);
      const col = nextIndex % 4;

      setPallet([...pallet, { row, col }]);

      const serial = serialNumber;
      dispatch(addSerial(serial));

      setElements([]);
      incrementBoxCounter();
    }
  };

  const incrementProductCounter = () => {
    setCounterProduct((prevCounter) => prevCounter + 1);
  };

  const decrementProductCounter = () => {
    setCounterProduct((prevCounter) => prevCounter - 1);
  };

  const incrementBoxCounter = () => {
    setCounterBox((prevCounter) => prevCounter + 1);
  };

  const decrementBoxCounter = () => {
    setCounterBox((prevCounter) => prevCounter - 1);
  };

  return (
    <>
      <div className="px-4 sm:px-6 lg:px-8 py-2 w-full max-w-10xl mx-auto">
        <div className="max-w-full mx-4 py-0 sm:mx-auto sm:px-6 lg:px-4">
          <header>
            <div className="mt-8">
              <div className="flex items-center justify-between h-16 -mb-px">
                <div></div>
                {/* Header: Right side */}
                <div className="flex items-center space-x-3">
                  {/* {Object.keys(orderSelected).length === 0 ? null : (
                    <button
                      onClick={handleNew}
                      className="border border-slate-300 rounded w-32 h-12 text-base flex justify-center font-semibold"
                    >
                      <Add
                        className="mr-2 my-auto bg-transparent"
                        color="black"
                        size={20}
                      />
                      <span className="my-auto text-black font-semibold">
                        Nuevo
                      </span>
                    </button>
                  )} */}

                  <button
                    onClick={handleNew}
                    className="border border-slate-300 rounded w-64 h-12 text-base flex justify-center font-semibold"
                  >
                    <BoxAdd
                      className="mr-2 my-auto bg-transparent"
                      color="black"
                      size={20}
                    />
                    <span className="my-auto text-black font-semibold">
                      Nueva cajas
                    </span>
                  </button>

                  <button
                    onClick={handleCloseBox}
                    className="border border-slate-300 rounded w-64 h-12 text-base flex justify-center font-semibold"
                  >
                    <ArchiveBox
                      className="mr-2 my-auto bg-transparent"
                      color="black"
                      size={20}
                    />
                    <span className="my-auto text-black font-semibold">
                      Cerrar caja
                    </span>
                  </button>

                  <button
                    onClick={handleClosePallet}
                    className="border border-slate-300 rounded w-64 h-12 text-base flex justify-center font-semibold"
                  >
                    <HambergerMenu
                      className="mr-2 my-auto bg-transparent"
                      color="black"
                      size={20}
                    />
                    <span className="my-auto text-black font-semibold">
                      Cerrar pallet
                    </span>
                  </button>

                  <BrowserPrintComponent />

                  <div style={{ display: "none" }}>
                    <LabelPrinting
                      ref={labelRef}
                      pallet={
                        barcodePallet != "Nuevo pallet"
                          ? barcodePallet
                          : "Undefined"
                      }
                      qty={
                        totalMontadosValue.length > 0
                          ? totalMontadosValue
                          : "Undefined"
                      }
                      order={
                        Object.keys(orderSelected).length != 0
                          ? orderSelected.aufnr
                          : "Undefined"
                      }
                      product={
                        Object.keys(orderSelected).length != 0
                          ? orderSelected.matnr
                          : "Undefined"
                      }
                    />
                  </div>
                </div>
              </div>
            </div>
          </header>

          <div className="max-w-full mx-4 py-0 sm:mx-auto">
            <div className="sm:flex sm:space-x-4">
              {/* Pallet view */}
              {/* {Object.keys(orderSelected).length === 0 ? (
                <section className="inline-block align-bottom rounded-lg border border-slate-200 text-left overflow-hidden mb-4 w-full sm:w-1/3 sm:my-4">
                  <div className="bg-white p-5">
                    <div className="sm:flex sm:items-start bg-white">
                      <div className="bg-white text-center sm:mt-0 sm:ml-2 sm:text-left">
                        <div className="flex items-center">
                          <Grid8 className="mr-2" color="#A0A2A6" size={20} />
                          <h3 className="bg-white text-md font-medium text-gray">
                            Pallet
                          </h3>
                        </div>
                        <p className="bg-white text-3xl font-bold text-black">
                          {Object.keys(orderSelected).length === 0
                            ? "Selecciona órden"
                            : barcodePallet}
                        </p>
                      </div>
                    </div>
                  </div>
                </section>
              ) : (
                <button
                  onClick={handleClickNewPallet}
                  className="inline-block align-bottom rounded-lg border border-slate-200 text-left overflow-hidden mb-4 w-full sm:w-1/3 sm:my-4"
                >
                  <div className="bg-white p-5">
                    <div className="sm:flex sm:items-start bg-white">
                      <div className="bg-white text-center sm:mt-0 sm:ml-2 sm:text-left">
                        <div className="flex items-center">
                          <Grid8 className="mr-2" color="#A0A2A6" size={20} />
                          <h3 className="bg-white text-md font-medium text-gray">
                            Pallet
                          </h3>
                        </div>
                        <p
                          className="bg-white text-3xl font-bold text-black"
                          onClick={handleClickNewPallet}
                        >
                          {Object.keys(orderSelected).length === 0
                            ? "Selecciona órden"
                            : barcodePallet}
                        </p>
                      </div>
                    </div>
                  </div>
                </button>
              )} */}

              <section className="inline-block align-bottom rounded-lg border border-slate-200 text-left overflow-hidden mb-4 w-full sm:w-1/3 sm:my-4">
                <div className="bg-white p-5">
                  <div className="sm:flex sm:items-start bg-white">
                    <div className="bg-white text-center sm:mt-0 sm:ml-2 sm:text-left">
                      <div className="flex items-center">
                        <Grid8 className="mr-2" color="#A0A2A6" size={20} />
                        <h3 className="bg-white text-md font-medium text-gray">
                          Pallet
                        </h3>
                      </div>

                      <p className="bg-white text-3xl font-bold text-black">
                        {palletNumber}
                      </p>
                    </div>
                  </div>
                </div>
              </section>

              <section className="inline-block align-bottom rounded-lg border border-slate-200 text-left overflow-hidden mb-4 sm:w-1/3 sm:my-4">
                <div className="bg-white p-5">
                  <div className="sm:flex sm:items-start bg-white">
                    <div className="bg-white text-center sm:mt-0 sm:ml-2 sm:text-left">
                      <div className="flex items-center">
                        <Menu
                          variant="Outline"
                          className="mr-2"
                          color="#A0A2A6"
                          size={20}
                        />
                        <h3 className="bg-white text-md font-medium text-gray">
                          Número de serial actual
                        </h3>
                      </div>
                      {/* <p className="bg-white text-3xl font-bold text-black">
                        {selectedProduct &&
                        selectedProduct.product &&
                        selectedProduct.product.matnr ? (
                          <p className="bg-white text-3xl font-bold text-black">
                            {selectedProduct.product.matnr}
                          </p>
                        ) : (
                          <p className="bg-white text-3xl font-bold text-black">
                            Dato no disponible
                          </p>
                        )}
                      </p> */}
                      {serialNumber && (
                        <p className="bg-white text-3xl font-bold text-black">
                          {serialNumber}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              </section>

              {/* <section className="inline-block align-bottom rounded-lg border border-slate-200 text-left overflow-hidden mb-4 w-full sm:w-1/6 sm:my-4">
                <div className="bg-white p-5">
                  <div className="sm:flex sm:items-start bg-white">
                    <div className="bg-white text-center sm:mt-0 sm:ml-2 sm:text-left">
                      <div className="flex items-center">
                        <HashtagSquare
                          variant="Outline"
                          className="mr-2"
                          color="#A0A2A6"
                          size={20}
                        />
                        <h3 className="bg-white text-md font-medium text-gray">
                          Cantidad caja
                        </h3>
                      </div>

                      <div className="bg-white text-3xl font-bold text-black flex items-center">
                        <input
                          className="w-36 border border-transparent focus:border-transparent focus:outline-none"
                          type="text"
                          placeholder="Cantidad"
                          ref={inputRef}
                          value={value}
                          onChange={handleChange}
                          onKeyPress={handleKeyPress} // Llama a handleKeyPress cuando se presiona una tecla
                          disabled={!editable}
                        />
                        {editable ? (
                          <button onClick={handleSave} className="ml-2">
                            <Lock color="#A0A2A6" size={20} />
                          </button>
                        ) : (
                          <button onClick={toggleEditable} className="ml-2">
                            <Edit color="#A0A2A6" size={20} />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </section> */}

              <section className="inline-block align-bottom rounded-lg border border-slate-200 text-left overflow-hidden mb-4 w-full sm:w-1/6 sm:my-4">
                <div className="bg-white p-5">
                  <div className="sm:flex sm:items-start bg-white">
                    <div className="bg-white text-center sm:mt-0 sm:ml-2 sm:text-left">
                      <div className="flex items-center">
                        <Quant
                          variant="Outline"
                          className="mr-2"
                          color="#A0A2A6"
                          size={20}
                        />
                        <h3 className="bg-white text-md font-medium text-gray">
                          Producto
                        </h3>
                      </div>

                      <div className="bg-white text-3xl font-bold text-black flex items-center">
                        {counterProduct !== undefined &&
                        totalProducts !== undefined
                          ? `${counterProduct} de ${totalProducts}`
                          : "Datos no disponibles"}
                      </div>
                    </div>
                  </div>
                </div>
              </section>

              <section className="inline-block align-bottom rounded-lg border border-slate-200 text-left overflow-hidden mb-4 w-full sm:w-1/6 sm:my-4">
                <div className="bg-white p-5">
                  <div className="sm:flex sm:items-start bg-white">
                    <div className="bg-white text-center sm:mt-0 sm:ml-2 sm:text-left">
                      <div className="flex items-center">
                        <Box1
                          variant="Outline"
                          className="mr-2"
                          color="#A0A2A6"
                          size={20}
                        />
                        <h3 className="bg-white text-md font-medium text-gray">
                          Caja
                        </h3>
                      </div>

                      <div className="bg-white text-3xl font-bold text-black flex items-center">
                        {`${counterBox} de 32`}
                      </div>
                    </div>
                  </div>
                </div>
              </section>

              <section className="inline-block align-bottom rounded-lg border border-slate-200 text-left overflow-hidden mb-4 w-full sm:w-1/6 sm:my-4">
                <div className="bg-white p-5">
                  <div className="sm:flex sm:items-start bg-white">
                    <div className="bg-white text-center sm:mt-0 sm:ml-2 sm:text-left">
                      <div className="flex items-center">
                        <Grid8
                          variant="Outline"
                          className="mr-2"
                          color="#A0A2A6"
                          size={20}
                        />
                        <h3 className="bg-white text-md font-medium text-gray">
                          Pallet
                        </h3>
                      </div>

                      <div className="bg-white text-3xl font-bold text-black flex items-center">
                        1 de 1
                      </div>
                    </div>
                  </div>
                </div>
              </section>

              {/* <section className="inline-block align-bottom rounded-lg border border-slate-200 text-left overflow-hidden mb-4 w-full sm:w-1/6 sm:my-4">
                <div className="bg-white p-5">
                  <div className="sm:flex sm:items-start bg-white">
                    <div className="bg-white text-center sm:mt-0 sm:ml-2 sm:text-left">
                      <div className="flex items-center">
                        <Health className="mr-2" color="#A0A2A6" size={20} />
                        <h3 className="bg-white text-md font-medium text-gray">
                          Total en caja
                        </h3>
                      </div>

                      <div className="bg-white text-3xl font-bold text-black flex items-center">
                        <input
                          className="w-36 border border-transparent focus:border-transparent focus:outline-none"
                          type="text"
                          placeholder="Cantidad"
                          ref={totalMontadosRef}
                          value={totalMontadosValue}
                          onChange={handleChangeMontados}
                          onKeyPress={handleKeyPressMontados} // Llama a handleKeyPress cuando se presiona una tecla
                          disabled={!totalMontadosEditable}
                        />
                        {totalMontadosEditable ? (
                          <button onClick={handleSaveMontados} className="ml-2">
                            <Lock color="#A0A2A6" size={20} />
                          </button>
                        ) : (
                          <button
                            onClick={toggleEditableMontados}
                            className="ml-2"
                          >
                            <Edit color="#A0A2A6" size={20} />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </section> */}
            </div>

            <div className="flex space-x-4">
              <div className="flex flex-col space-y-4 w-full sm:w-1/4 mt-4 mb-4">
                <section className="inline-block align-bottom rounded-lg border border-slate-200 text-left overflow-hidden mb-4 w-full flex-grow">
                  <div className="bg-white p-5">
                    <div className="sm:flex sm:items-start bg-white">
                      <div className="bg-white text-center sm:mt-0 sm:ml-2 sm:text-left">
                        <div className="flex items-center">
                          <Notepad2
                            className="mr-2"
                            color="#A0A2A6"
                            size={20}
                          />
                          <h3 className="bg-white text-md font-medium text-gray">
                            Órden
                          </h3>
                        </div>
                        <p className="bg-white text-3xl font-bold text-black">
                          {Object.keys(orderSelected).length === 0
                            ? "Selecciona órden"
                            : orderSelected.aufnr}
                        </p>
                      </div>
                    </div>
                  </div>
                </section>

                <section className="inline-block align-bottom rounded-lg border border-slate-200 text-left overflow-hidden mb-4 w-full flex-grow">
                  <div className="bg-white p-5">
                    <div className="sm:flex sm:items-start bg-white">
                      <div className="bg-white text-center sm:mt-0 sm:ml-2 sm:text-left">
                        <div className="flex items-center">
                          <Box1
                            variant="Outline"
                            className="mr-2"
                            color="#A0A2A6"
                            size={20}
                          />
                          <h3 className="bg-white text-md font-medium text-gray">
                            Producto
                          </h3>
                        </div>
                        <p className="bg-white text-3xl font-bold text-black">
                          {Object.keys(orderSelected).length === 0
                            ? "--------"
                            : orderSelected.matnr}
                        </p>
                      </div>
                    </div>
                  </div>
                </section>
              </div>

              {/* <section className="inline-block align-bottom rounded-lg border border-slate-200 text-left overflow-hidden mb-4 w-full sm:w-1/3 sm:my-4">
                <div className="bg-white p-5">
                  <h3 className="bg-white text-md font-medium text-gray">
                    Semáforo
                  </h3>
                  {typeof trafficLightState === "number" ? (
                    trafficLightState === 0 ? (
                      <img
                        src={greenLight}
                        alt="Semáforo verde"
                        className="w-24 h-24"
                      />
                    ) : (
                      <img
                        src={redLight}
                        alt="Semáforo rojo"
                        className="w-24 h-24"
                      />
                    )
                  ) : (
                    <h3 className="bg-white text-2xl font-semibold text-black">
                      Resultados de pruebas no disponibles.
                    </h3>
                  )}
                </div>
              </section> */}

              <section className="inline-block align-bottom rounded-lg border border-slate-200 text-left overflow-hidden mb-4 w-full sm:w-1/3 sm:my-4">
                <div className="bg-white p-5 flex flex-col items-center">
                  <h3 className="text-md font-medium text-gray mb-4 self-start">
                    {" "}
                    {/* Utilizamos self-start para alinear el texto a la izquierda */}
                    Semáforo
                  </h3>
                  {/* Condicional para mostrar la imagen del semáforo según el valor de trafficLightState */}
                  {typeof trafficLightState === "number" ? (
                    trafficLightState === 0 ? (
                      <img
                        src={greenLight}
                        alt="Semáforo verde"
                        className="w-24 h-24"
                      />
                    ) : (
                      <img
                        src={redLight}
                        alt="Semáforo rojo"
                        className="w-24 h-24"
                      />
                    )
                  ) : (
                    <h3 className="text-2xl font-semibold text-black">
                      Resultados de pruebas no disponibles.
                    </h3>
                  )}
                </div>
              </section>

              <section className="inline-block align-bottom rounded-lg border border-slate-200 text-left overflow-hidden mb-4 w-full sm:w-1/3 sm:my-4">
                <div className="bg-white p-5">
                  <div className="sm:flex sm:items-start bg-white">
                    <div className="bg-white text-center sm:mt-0 sm:ml-2 sm:text-left">
                      <div className="flex items-center">
                        <Box className="mr-2" color="#A0A2A6" size={20} />
                        <h3 className="bg-white text-md font-medium text-gray">
                          Armado de caja
                        </h3>
                      </div>
                      <div className="mt-4">
                        {data && data[0] && data[0].box ? (
                          <GridView
                            rows={data[0].box.width}
                            columns={data[0].box.length}
                            elements={elements}
                          />
                        ) : (
                          <p className="text-gray-500">
                            No hay datos disponibles.
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </section>

              <section className="inline-block align-bottom rounded-lg border border-slate-200 text-left overflow-hidden mb-4 w-full sm:w-1/3 sm:my-4">
                <div className="bg-white p-5">
                  <div className="sm:flex sm:items-start bg-white">
                    <div className="bg-white text-center sm:mt-0 sm:ml-2 sm:text-left">
                      <div className="flex items-center">
                        <Grid8 className="mr-2" color="#A0A2A6" size={20} />
                        <h3 className="bg-white text-md font-medium text-gray">
                          Armado de Pallet
                        </h3>
                      </div>
                      <div className="mt-4">
                        {data && data[0] && data[0].pallet ? (
                          <GridViewPallet
                            rows={data[0].pallet.num_lines}
                            columns={data[0].pallet.box_x_line}
                            elements={pallet}
                          />
                        ) : (
                          <p className="text-gray-500">
                            No hay datos disponibles.
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </section>
            </div>

            <div className="max-w-full mx-4 py-0 sm:mx-auto">
              <div className="sm:flex sm:space-x-4">
                <section
                  style={{ height: "245px", overflowY: "scroll" }}
                  className="inline-block align-bottom rounded-lg border border-slate-200 text-left mb-4 w-full sm:w-1/3 sm:my-4"
                >
                  <div className="bg-white p-5">
                    <h3 className="bg-white text-md font-medium text-gray">
                      Log de eventos
                    </h3>
                    <div
                      className="bg-white text-sm text-black"
                      style={{ maxHeight: "450px", overflowY: "auto" }}
                    >
                      <button
                        style={{
                          marginRight: "10px",
                          padding: "10px",
                          backgroundColor: "#007BFF",
                          color: "white",
                          border: "none",
                          cursor: "pointer",
                        }}
                        onClick={addElement}
                      >
                        Agregar Elemento
                      </button>
                      <button
                        style={{
                          padding: "10px",
                          backgroundColor: "#DC3545",
                          color: "white",
                          border: "none",
                          cursor: "pointer",
                        }}
                        onClick={removeElement}
                      >
                        Eliminar Último Elemento
                      </button>
                      {paletizationLog
                        .slice()
                        .reverse()
                        .map((event, index, array) => (
                          <p
                            key={index}
                            style={{
                              fontWeight: index === 0 ? "bold" : "normal",
                            }}
                          >
                            <span style={{ color: "green" }}>
                              {formatTimestampToDDMMYYYYHHMMSS(event.timestamp)}
                            </span>{" "}
                            - {event.text}{" "}
                          </p>
                        ))}
                    </div>
                  </div>
                </section>
              </div>

              {/* <section
                style={{
                  maxHeight: "645px",
                  minHeight: "200px",
                  overflowY: "scroll",
                }}
                className="inline-block align-bottom rounded-lg border border-slate-200 text-left overflow-hidden mb-4 w-full sm:my-4 w-3/4"
              >
                <div className="bg-white p-5">
                  <h3 className="bg-white text-md font-medium text-gray">
                    Listado de componentes
                  </h3>
                  <div
                    className="flex justify-start"
                    style={{ marginLeft: "-10px" }}
                  >
                    <ComponentsTable selectedItems={handleSelectedItems} />
                    <div></div>
                  </div>
                </div>
              </section> */}
            </div>
          </div>

          <hr class="solid" />
          <div className="mt-8 flex">
            <h3 className="text-black text-2xl capitalize font-semibold text-gray-400 tracking-tight">
              Información adicional
            </h3>
          </div>

          <div className="sm:flex sm:space-x-4 mt-4">
            <section className="inline-block align-bottom rounded-lg border border-slate-200 text-left mb-4 sm:w-2/3 sm:my-4">
              <div className="bg-white p-5">
                <h3 className="bg-rose-100 text-md font-medium text-gray">
                  Histórico
                </h3>
                <div
                  className="bg-white text-sm text-black"
                  style={{ maxHeight: "450px", overflowY: "auto" }}
                >
                  <GraphicHistory />
                </div>
              </div>
            </section>
          </div>
        </div>
      </div>

      <div className="m-1.5">
        {/* Start */}

        <ModalBlank
          id="danger-modal"
          modalOpen={dangerEditQtyPalletModalOpen}
          setModalOpen={setDangerEditQtyPalletModalOpen}
        >
          <div className="p-5 flex space-x-4">
            {/* Icon */}
            <div className="w-10 h-10 rounded-full flex items-center justify-center shrink-0 bg-rose-100">
              <svg
                className="w-4 h-4 shrink-0 fill-current text-rose-500"
                viewBox="0 0 16 16"
              >
                <path d="M8 0C3.6 0 0 3.6 0 8s3.6 8 8 8 8-3.6 8-8-3.6-8-8-8zm0 12c-.6 0-1-.4-1-1s.4-1 1-1 1 .4 1 1-.4 1-1 1zm1-3H7V4h2v5z" />
              </svg>
            </div>
            {/* Content */}
            <div>
              {/* Modal header */}
              <div className="mb-2">
                <div className="text-lg font-semibold text-slate-800">
                  Editar Cantidad pallet
                </div>
              </div>
              {/* Modal content */}
              <div className="text-sm text-black mb-10">
                <div className="space-y-2">
                  <p>
                    ¿Estás seguro que deseas cambiar la cantidad estándar de
                    unidades por Pallet? La cantidad estándar es 1452, si deseas
                    proceder da click en "Si, editar"
                  </p>
                </div>
              </div>
              {/* Modal footer */}
              <div className="flex flex-wrap justify-end space-x-2">
                <button
                  className="btn-sm border-slate-200 hover:border-slate-300 text-slate-600"
                  onClick={(e) => {
                    e.stopPropagation();
                    setDangerEditQtyPalletModalOpen(false);
                    setConfirmEditQtyPallet(false);
                  }}
                >
                  Cancelar
                </button>
                <button
                  className="btn-sm bg-rose-500 hover:bg-rose-600 text-white"
                  onClick={(e) => {
                    e.stopPropagation();
                    setConfirmEditQtyPallet(true);
                    setDangerEditQtyPalletModalOpen(false);
                  }}
                >
                  Si, editar
                </button>
              </div>
            </div>
          </div>
        </ModalBlank>
        {/* End */}
      </div>

      <div className="m-1.5">
        {/* Start */}

        <ModalBlank
          id="danger-modal"
          modalOpen={dangerDiffValues}
          setModalOpen={setDangerDiffValues}
        >
          <div className="p-5 flex space-x-4">
            {/* Icon */}
            <div className="w-10 h-10 rounded-full flex items-center justify-center shrink-0 bg-rose-100">
              <svg
                className="w-4 h-4 shrink-0 fill-current text-rose-500"
                viewBox="0 0 16 16"
              >
                <path d="M8 0C3.6 0 0 3.6 0 8s3.6 8 8 8 8-3.6 8-8-3.6-8-8-8zm0 12c-.6 0-1-.4-1-1s.4-1 1-1 1 .4 1 1-.4 1-1 1zm1-3H7V4h2v5z" />
              </svg>
            </div>
            {/* Content */}
            <div>
              {/* Modal header */}
              <div className="mb-2">
                <div className="text-lg font-semibold text-slate-800">
                  Confirmar edición
                </div>
              </div>
              {/* Modal content */}
              <div className="text-sm text-black mb-10">
                <div className="space-y-2">
                  <p>
                    El total montado difiere de la cantidad estándar definida.
                    La cantidad estándar por pallet son 1452 unidades. ¿Deseas
                    confirmar el cambio y montar solo {totalMontadosValue}{" "}
                    unidades? Haz clic en 'Sí' para proceder.
                  </p>
                </div>
              </div>
              {/* Modal footer */}
              <div className="flex flex-wrap justify-end space-x-2">
                <button
                  className="btn-sm border-slate-200 hover:border-slate-300 text-slate-600"
                  onClick={(e) => {
                    e.stopPropagation();
                    setTotalMontadosValue("");
                    setDangerDiffValues(false);
                    setConfirmEditDiffValues(false);
                  }}
                >
                  Cancelar
                </button>
                <button
                  className="btn-sm bg-rose-500 hover:bg-rose-600 text-white"
                  onClick={(e) => {
                    e.stopPropagation();
                    setConfirmEditDiffValues(true);
                    setDangerDiffValues(false);
                  }}
                >
                  Si, proceder
                </button>
              </div>
            </div>
          </div>
        </ModalBlank>
        {/* End */}
      </div>
    </>
  );
}

export default PaletizationView;
